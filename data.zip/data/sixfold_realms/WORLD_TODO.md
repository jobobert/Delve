# World TODO

All prior warnings cleared. Current validate.py output: PASSED (3 warnings — all are
"Multi-line inline table (engine extension - OK)" notices, not real issues).

# riverlands_confluence

- [x] rl_ferry_berth_peaks is unreachable. I have tried to add some exits. Is the rooms.toml malformed?

# dragon_peaks

- []

# mistfen_expanse

- []

# verdant_heartwood

- []

# gloamreach

- []

# mycelial_plains

- []

# core_chamber

- []

# Core ideas/mechanics/etc

